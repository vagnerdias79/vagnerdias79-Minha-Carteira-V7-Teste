import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type MarketQuote = {
  price: number;
  changePercent: number;
  currency: string;
  marketTime: number | null;
  source: string;
};

function validSymbol(value: string) {
  return /^[A-Z0-9.-]{1,12}$/.test(value);
}

async function yahooQuote(symbol: string, market: "BR" | "US"): Promise<MarketQuote | null> {
  const target = market === "BR" && !symbol.includes(".") ? `${symbol}.SA` : symbol.replace(".", "-");
  try {
    const response = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(target)}?interval=5m&range=1d`,
      { cache: "no-store", headers: { "User-Agent": "Mozilla/5.0 NorthCapital/33.10" } },
    );
    if (!response.ok) return null;
    const meta = (await response.json())?.chart?.result?.[0]?.meta;
    const price = Number(meta?.regularMarketPrice);
    const previous = Number(meta?.chartPreviousClose ?? meta?.previousClose);
    return price > 0
      ? {
          price,
          changePercent: previous > 0 ? ((price - previous) / previous) * 100 : 0,
          currency: meta?.currency || (market === "BR" ? "BRL" : "USD"),
          marketTime: Number(meta?.regularMarketTime) || null,
          source: "YAHOO",
        }
      : null;
  } catch {
    return null;
  }
}

async function stooqQuote(symbol: string): Promise<MarketQuote | null> {
  const target = symbol.toLowerCase().replace(".", "-") + ".us";
  try {
    const response = await fetch(
      `https://stooq.com/q/l/?s=${encodeURIComponent(target)}&f=sd2t2ohlcv&h&e=csv`,
      { cache: "no-store" },
    );
    if (!response.ok) return null;
    const rows = (await response.text()).trim().split(/\r?\n/);
    if (rows.length < 2) return null;
    const headers = rows[0].split(",");
    const values = rows[1].split(",");
    const record = Object.fromEntries(headers.map((key, index) => [key, values[index]]));
    const price = Number(record.Close);
    return price > 0
      ? { price, changePercent: 0, currency: "USD", marketTime: null, source: "STOOQ EOD" }
      : null;
  } catch {
    return null;
  }
}

async function brapiQuotes(symbols: string[]) {
  const quotes: Record<string, MarketQuote> = {};
  if (!symbols.length) return quotes;
  try {
    const response = await fetch(
      `https://brapi.dev/api/quote/${encodeURIComponent(symbols.join(","))}?fundamental=false`,
      { cache: "no-store" },
    );
    if (!response.ok) return quotes;
    const data = await response.json();
    for (const item of data?.results || []) {
      const symbol = String(item?.symbol || "").toUpperCase().replace(/\.SA$/, "");
      const price = Number(item?.regularMarketPrice);
      if (validSymbol(symbol) && price > 0) {
        quotes[symbol] = {
          price,
          changePercent: Number(item?.regularMarketChangePercent) || 0,
          currency: item?.currency || "BRL",
          marketTime: item?.regularMarketTime
            ? Math.floor(new Date(item.regularMarketTime).getTime() / 1000)
            : null,
          source: "BRAPI",
        };
      }
    }
  } catch {
    // The next provider remains available.
  }
  return quotes;
}

async function twelveDataQuotes(symbols: string[], brSymbols: Set<string>) {
  const apiKey = process.env.TWELVE_DATA_API_KEY?.trim();
  const quotes: Record<string, MarketQuote> = {};
  if (!apiKey || !symbols.length) return quotes;
  const providerSymbols = symbols.map((symbol) => (brSymbols.has(symbol) ? `${symbol}:BVMF` : symbol));
  try {
    const response = await fetch(
      `https://api.twelvedata.com/quote?symbol=${encodeURIComponent(providerSymbols.join(","))}&apikey=${encodeURIComponent(apiKey)}`,
      { cache: "no-store" },
    );
    if (!response.ok) return quotes;
    const payload = await response.json();
    const records = providerSymbols.length === 1 ? { [providerSymbols[0]]: payload } : payload;
    for (const providerSymbol of providerSymbols) {
      const item = records?.[providerSymbol] || records?.[providerSymbol.split(":")[0]];
      const price = Number(item?.close);
      const symbol = providerSymbol.split(":")[0];
      if (price > 0) {
        quotes[symbol] = {
          price,
          changePercent: Number(item?.percent_change) || 0,
          currency: brSymbols.has(symbol) ? "BRL" : "USD",
          marketTime: item?.timestamp ? Number(item.timestamp) : null,
          source: "TWELVE DATA",
        };
      }
    }
  } catch {
    // Public fallbacks below preserve availability.
  }
  return quotes;
}

export async function GET(request: NextRequest) {
  const raw = request.nextUrl.searchParams.get("symbols") || "";
  const symbols = [...new Set(raw.split(",").map((s) => s.trim().toUpperCase()).filter(validSymbol))].slice(0, 40);
  const brSymbols = new Set(
    (request.nextUrl.searchParams.get("br") || "")
      .split(",")
      .map((s) => s.trim().toUpperCase())
      .filter(validSymbol),
  );
  const brList = symbols.filter((symbol) => brSymbols.has(symbol));
  const licensed = await twelveDataQuotes(symbols, brSymbols);
  const brapi = await brapiQuotes(brList.filter((symbol) => !licensed[symbol]));

  const entries = await Promise.all(
    symbols.map(async (symbol) => {
      if (licensed[symbol]) return [symbol, licensed[symbol]] as const;
      if (brapi[symbol]) return [symbol, brapi[symbol]] as const;
      const market = brSymbols.has(symbol) ? "BR" : "US";
      const fallback =
        market === "US"
          ? (await stooqQuote(symbol)) || (await yahooQuote(symbol, market))
          : await yahooQuote(symbol, market);
      return [symbol, fallback] as const;
    }),
  );

  const [fxYahoo, fxReference] = await Promise.all([
    yahooQuote("BRL=X", "US"),
    fetch("https://api.frankfurter.app/latest?from=USD&to=BRL", { cache: "no-store" })
      .then((response) => (response.ok ? response.json() : null))
      .catch(() => null),
  ]);
  const quotes = Object.fromEntries(entries.filter(([, value]) => value));
  const sources = [...new Set(Object.values(quotes).map((quote) => quote.source))];

  return NextResponse.json(
    {
      fx: Number(fxYahoo?.price) || Number(fxReference?.rates?.BRL) || null,
      fxSource: fxYahoo?.price ? "YAHOO" : "FRANKFURTER",
      quotes,
      coverage: { updated: Object.keys(quotes).length, total: symbols.length },
      sources,
      licensedProviderConfigured: Boolean(process.env.TWELVE_DATA_API_KEY?.trim()),
      cadenceMinutes: 15,
      updatedAt: new Date().toISOString(),
    },
    {
      headers: {
        "Cache-Control": "public, s-maxage=900, stale-while-revalidate=86400",
      },
    },
  );
}
